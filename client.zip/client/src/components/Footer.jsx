import React from 'react'
import Logo from "../../src/img/logo.png"

const Footer = () => {
    return (
        <div>
            <footer>
                <img src={Logo} alt="" srcSet="" />
                <span>
                    Made with ♥️ and <b>React.js</b>.
                </span>
            </footer>
        </div>
    )
}

export default Footer