import React from 'react'
import { Link } from 'react-router-dom'
import Edit from '../img/edit.png'
import Delete from '../img/delete.png'
import Menu from '../components/Menu'

const Single = () => {
  return (
    <div className='single'>
      <div className="content">
        <img src="https://images.pexels.com/photos/305821/pexels-photo-305821.jpeg?auto=compress&cs=tinysrgb&w=1600" alt="" srcset="" />
        <div className="user">
          <img src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="" srcset="" />
          <div className="info">
            <span>John</span>
            <p>Posted 2 days ago</p>
          </div>
          <div className="edit">
            <Link to={`/write?edit=2`}>
              <img src={Edit} alt="" srcset="" />
            </Link>
            <img src={Delete} alt="" srcset="" />
          </div>
        </div>
        <h1>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sequi dolorum perferendis, nostrum a iure voluptatum veritatis dolores, quisquam sit nisi rerum ab explicabo culpa quos? Doloribus velit eos pariatur ducimus.</h1>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Perferendis numquam reprehenderit earum dolorum quibusdam. Veniam aspernatur accusamus cum tenetur sint deserunt ratione molestias. Quaerat at aut delectus nesciunt vel voluptates.
          <br />
          <br />
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Perferendis numquam reprehenderit earum dolorum quibusdam. Veniam aspernatur accusamus cum tenetur sint deserunt ratione molestias. Quaerat at aut delectus nesciunt vel voluptates.
          <br />
          <br />
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Perferendis numquam reprehenderit earum dolorum quibusdam. Veniam aspernatur accusamus cum tenetur sint deserunt ratione molestias. Quaerat at aut delectus nesciunt vel voluptates.
        </p>
      </div>
    <Menu />
    </div>
  )
}

export default Single